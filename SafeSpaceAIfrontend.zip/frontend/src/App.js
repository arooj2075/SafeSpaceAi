import React, { useState } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [inputText, setInputText] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleCheck = async () => {
    if (!inputText) return;
    setLoading(true);
    setResult(null);
    try {
      const res = await axios.post("http://localhost:5000/check", {
        inputText
      });
      setResult(res.data);
    } catch (err) {
      setResult({ error: "Error connecting to backend" });
    }
    setLoading(false);
  };

  const getColor = (risk) => {
    if (risk === "High") return "#ff4d4f";
    if (risk === "Medium") return "#faad14";
    return "#52c41a"; // Low
  };

  return (
    <div className="app-container">
      <h1>🛡 SafeSpace AI</h1>
      <p className="creator">Created by Arooj</p>
      <p className="subtitle">Analyze messages or links for safety risks</p>

      <div className="input-section">
        <input
          type="text"
          placeholder="Paste link or message"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
        />
        <button onClick={handleCheck} disabled={loading}>
          {loading ? "Analyzing..." : "Analyze"}
        </button>
      </div>

      {result && (
        <div
          className="result-card"
          style={{ borderLeft: `6px solid ${getColor(result.risk_level)}` }}
        >
          {result.error ? (
            <p className="error">{result.error}</p>
          ) : (
            <>
              <h2 style={{ color: getColor(result.risk_level) }}>
                Risk Level: {result.risk_level}
              </h2>
              <p><strong>Confidence:</strong> {result.confidence_score}%</p>
              <p><strong>Threat Type:</strong> {result.threat_type}</p>
              <p><strong>Explanation:</strong> {result.explanation}</p>
              <p><strong>Recommended Action:</strong> {result.recommended_action}</p>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default App;